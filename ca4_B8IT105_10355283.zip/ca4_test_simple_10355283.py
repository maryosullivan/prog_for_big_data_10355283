# Continuous Assessment 4 
# B8IT105 - Programming for Big Data 
# Mary O'Sullivan - 10355283
# ca4_test_simple_10355283.py

# Test File

import unittest

from ca4_simple_10355283 import get_commits, read_file

class TestCommits(unittest.TestCase):
    def setUp(self):
        self.data = read_file('changes_python.log')
        commits = get_commits(self.data)

    def test_number_of_lines(self):
        self.assertEqual(5255, len(self.data))

    def test_number_of_commits(self):
        commits = get_commits(self.data)
        self.assertEqual(422, len(commits))

    def test_first_commit(self):
        commits = get_commits(self.data)
        self.assertEqual('r1551925', commits[0]['revision'])
        self.assertEqual('Thomas', commits[0]['author'])
        self.assertEqual('2015-11-27', commits[0]['date'])
        self.assertEqual('16:57:44', commits[0]['time_stamp'])     
        self.assertEqual('2015', commits[0]['year'])
        self.assertEqual('Nov', commits[0]['month'])
        self.assertEqual('Renamed folder to the correct name', commits[0]['commit_details'])
       
    def test_tenth_commit(self):
        commits = get_commits(self.data)
        self.assertEqual('r1551334', commits[9]['revision'])
        self.assertEqual('Vincent', commits[9]['author'])
        self.assertEqual('2015-11-26', commits[9]['date'])
        self.assertEqual('14:20:12', commits[9]['time_stamp'])     
        self.assertEqual('2015', commits[9]['year'])
        self.assertEqual('Nov', commits[9]['month'])
        self.assertEqual('SFR-108 : using WL base & snc urls', commits[9]['commit_details'])
 
if __name__ == '__main__':
    unittest.main()
