# Continuous Assessment 4 
# B8IT105 - Programming for Big Data 
# Mary O'Sullivan - 10355283
# ca4_simple_10355283.py

# import csv capability
import csv

def read_file(changes_file):
    # use .strip to strip out the spaces and trim the line
    data = [line.strip() for line in open(changes_file, 'r')]
    return data

def get_commits(data):
    sep = 72*'-'
    commits = []
    current_commit = None
    index = 0
    while index < len(data):
        try:
            # parse each of the commits on the pipe delimeter and put them into a list of commits
            details = data[index + 1].split('|')
            commit_details = data[index+2:data.index(sep,index+1)]
            # create a dictionary object to assign each of the values 
            commit = {'revision': details[0].strip(),
                'author': details[1].strip(),
                'date': (details[2][0:11]).strip(),
                'year': (details[2][0:5]).strip(),
                'month': (details[2][36:40]).strip(),
                'time_stamp': (details[2][11:20]).strip(),
                'number_of_lines': (details[3].strip().split(' ')[0]), 
                'commit_details': commit_details[-1]
            }
            # add commit object to the commits array
            commits.append(commit)
            # update the index
            index = data.index(sep, index + 1)
        # expected error at end of the file
        except IndexError:
            break
    return commits

def get_authors(data):
    separator = 72*'-'
    commits = []
    row_index = 0
    while row_index < len(data):
        try:
            # find the first line in the file and split out based on the pipe delimeter
            details = data[row_index + 1].split('|')
            # create a dictionary object to assign each of the values 
            commit = {'revision': details[0].strip(),
            'author': details[1].strip(),
            'date': details[2].strip().split(' ')[0],
            'time': details[2].strip().split(' ')[1],
            'number of lines': details[3].strip().split(' ')[0],
            'comment': data[row_index+2:data.index('',row_index+1)]}

            # add the commit object to the commits array
            commits.append(commit)
            # update the index
            row_index = data.index(separator, row_index + 1) 
        # expected error at end of the file
        except IndexError: 
            break

    authors = {}
    for commit in commits:
        author = commit['author']
        if commit['author'] in authors:
            authors[author] = authors[author] + 1
        else:
            authors[author] = 1
    return authors
    
    
if __name__ == '__main__':
    # open the file and read all of the lines
    changes_file = 'changes_python.log'
    data = read_file(changes_file)
    commits = get_commits(data)

    # print commits
    print(commits)

    
    
    
# ***** Analysis of Dataset - Statistical Insights *****


# 1. Statistical Insight: The total number of commits 

number_of_commits = len(commits)
print 'There are:',number_of_commits,'commits in the file'    


# 2. Statistical Insight: The total number of commits by author

# open/write a get_authors csv file 
authors = get_authors(data)
print 'The following is the list of authors and number of commits:\n',authors
# create the file with the authors dictionary
with open('get_authors.csv', 'wb') as f:
    w = csv.DictWriter(f, authors.keys())
    w.writeheader()
    w.writerow(authors)

    
# 3. Statistical Insight: Create a csv file to explore the contents & visualise the output in Tableau

# open/write a csv file   
with open("ca4_output_10355283.csv",'wb') as f:
# use dictionary keys as headers in the csv file
    writer = csv.DictWriter(f, commits[0].keys())
    writer.writeheader()
    for d in commits:
        writer.writerow(d)    